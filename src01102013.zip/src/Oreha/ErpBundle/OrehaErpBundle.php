<?php

namespace Oreha\ErpBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OrehaErpBundle extends Bundle
{
}
