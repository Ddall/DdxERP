<?php
/*
 *  OrehaERP - allan.irdel
 *  DemoController.php - UTF-8
 */

namespace Oreha\ErpBundle\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Httpfoundation\Response;

use Oreha\UserBundle\Entity\User;

class DemoController extends Controller{

}