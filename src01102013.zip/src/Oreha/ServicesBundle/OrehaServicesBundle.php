<?php

namespace Oreha\ServicesBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OrehaServicesBundle extends Bundle
{
}
