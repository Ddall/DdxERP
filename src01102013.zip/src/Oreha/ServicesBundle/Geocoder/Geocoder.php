<?php
/**
 * Description of Geocoder
 *
 * @author Allan
 */

namespace Oreha\ervicesBundle\Geocoder;

class Geocoder {
    
    /**
     * 
     * @param type $addres
     */
    public function getCoordinates($addres){
        
    }
    
}