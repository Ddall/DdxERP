<?php

namespace ADesigns\CalendarBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ADesignsCalendarBundle extends Bundle
{
}
